package main

import (
	"github.com/gaoze1998/GolangWebFramework/InsideServer"
	"github.com/gaoze1998/GolangWebFrameworkDistrbutionTest/Config"
)

func main() {
	var is InsideServer.InsideServer
	Config.ConfigInit()
	is.Config(Config.Config)
	is.Serve()
}
