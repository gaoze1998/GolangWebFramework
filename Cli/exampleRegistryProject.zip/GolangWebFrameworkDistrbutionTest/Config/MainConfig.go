package Config

import (
	"github.com/gaoze1998/GolangWebFramework/InsideServer"
)

//Config 导出配置
var Config InsideServer.BaseConfig

//Config 配置
func ConfigInit() {
	Config = InsideServer.ConfigInit()
	//开启服务中心模式
	Config.Registry = true
	//配置服务中心注册端口
	Config.RegistryAddr = ":8089" // rpc默认端口
}
