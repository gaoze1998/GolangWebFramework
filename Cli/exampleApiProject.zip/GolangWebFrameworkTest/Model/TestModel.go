package Model

import (
	"github.com/gaoze1998/GolangWebFramework/ORM"
	"reflect"
)

type TestModel struct {
	Id int //必须有Id且其为主码
	Name int
	Password string
}

func (testModel TestModel) QueryTestModel() []reflect.Value{
	orm := ORM.GetOrNewORM()
	var rst []reflect.Value
	rst = orm.Query(testModel)
	return rst
}

func (testModel TestModel) InsertTestModel(){
	orm := ORM.GetOrNewORM()
	orm.Insert(testModel)
}

func (testModel TestModel) UpdateTestModel(){
	orm := ORM.GetOrNewORM()
	orm.Update(testModel)
}

func (testModel TestModel) DeleteTestModel(){
	orm := ORM.GetOrNewORM()
	orm.Delete(testModel)
}

// 测试事务
func (testModel TestModel) RawSQLTest(Sql string){
	orm := ORM.GetOrNewORM()
	orm.RawSQLExec(Sql)
}