package Router

import (
	"github.com/gaoze1998/GolangWebFrameworkTest/Controller"
	"github.com/gaoze1998/GolangWebFramwork/BaseRouter"
)

//RTableInit 初始化路由表
func RTableInit() *BaseRouter.Router{
	router := BaseRouter.Init()

	//在此处编写路由
	router.Register("/", &Controller.MainController{})
	router.Register("/second", &Controller.SecondController{})
	router.Register("/testmodel", &Controller.TestModelController{})

	return router
}
