package main

import (
	"github.com/gaoze1998/GolangWebFrameworkTest/Config"
	"github.com/gaoze1998/GolangWebFramework/InsideServer"
)

func main() {
	var is InsideServer.InsideServer
	Config.ConfigInit()
	is.Config(Config.Config)
	is.Serve()
}
