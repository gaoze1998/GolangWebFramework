package Config

import (
	"github.com/gaoze1998/GolangWebFrameworkTest/Model"
	"github.com/gaoze1998/GolangWebFrameworkTest/Router"
	"github.com/gaoze1998/GolangWebFramwork/InsideServer"
	"github.com/gaoze1998/GolangWebFramwork/ORM"
)

//Config 导出配置
var Config InsideServer.BaseConfig

//Config 配置
func ConfigInit() {
	Config = InsideServer.ConfigInit()
	Config.Addr = ":8082"
	Config.Router = Router.RTableInit()

	// 数据库连接配置
	orm := ORM.GetOrNewORM()
	orm.ConnectMySQLDB("root:g7096126z@/test?charset=utf8")

	// 注册模型
	orm.RegistModel(Model.TestModel{})

	// 同步数据库 模型没有改动可以删除这条语句，节省项目编译启动的时间
	//orm.ResetAndSyncDB(false)
}
