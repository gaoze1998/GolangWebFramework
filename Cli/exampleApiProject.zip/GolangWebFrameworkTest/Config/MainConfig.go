package Config

import (
	"github.com/gaoze1998/GolangWebFramework/Distrabution"
	"github.com/gaoze1998/GolangWebFramework/InsideServer"
	"github.com/gaoze1998/GolangWebFramework/ORM"
)

//Config 导出配置
var Config InsideServer.BaseConfig

//Config 配置
func ConfigInit() {
	Config = InsideServer.ConfigInit()
	Config.Addr = ":8082"
	Config.Router = Router.RTableInit()

	// 数据库连接配置
	orm := ORM.GetOrNewORM()
	orm.ConnectMySQLDB("root:g7096126z@/test?charset=utf8")

	// 注册模型
	orm.RegistModel(Model.TestModel{})

	// 向服务中心注册
	Distrabution.RegistBackend(Config.Addr, "gwft", "localhost:8089")

	// 同步数据库 模型没有改动可以删除这条语句，节省项目编译启动的时间
	//orm.ResetAndSyncDB(false)
}
