package Controller

import (
	"fmt"

	"github.com/gaoze1998/GolangWebFramework/BaseController"
	"github.com/gaoze1998/GolangWebFramework/Helper"
)

type TestModelController struct {
	BaseController.BaseController
}

func (tmc TestModelController) Get() {
	tmc.RespWriter.Header().Set("Access-Control-Allow-Origin", "*") //必须加
	err := tmc.Req.ParseForm()
	if err != nil {
		fmt.Println("表单解析错误")
		return
	}
	fmt.Println("Tmc get!")
	rst := Model.TestModel{}.QueryTestModel()
	//insertOne := Model.TestModel{
	//	Id:       0,
	//	Name:     1,
	//	Password: "123456",
	//}
	//insertOne.InsertTestModel()
	//insertTwo := Model.TestModel{
	//	Id:       2,
	//}
	//insertTwo.InsertTestModel()
	//insertTwo.UpdateTestModel()
	//insertTwo.DeleteTestModel()
	//multiSQLs := make([]string, 0)
	//multiSQLs = append(multiSQLs, "begin")
	//multiSQLs = append(multiSQLs, "insert into testmodel values(0, 2, '123456')")
	//multiSQLs = append(multiSQLs, "insert into testmodel values(0, 3, '456789')")
	//multiSQLs = append(multiSQLs, "commit")
	//for _, sql := range multiSQLs {
	//	insertTwo.RawSQLTest(sql)
	//}
	Helper.JsonizeWriter(tmc.RespWriter, rst)
}
