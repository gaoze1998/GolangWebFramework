package Controller

import (
	"github.com/gaoze1998/GolangWebFramework/BaseController"
	"fmt"
	"io"
)

type SecondController struct {
	BaseController.BaseController
}

func (mc SecondController) Get() {
	fmt.Println("SecondConTroller get!")
	io.WriteString(mc.RespWriter, "hello, get!\n")
}

func (mc SecondController) Post() {
	fmt.Println("SecondConTroller post!")
	io.WriteString(mc.RespWriter, "hello, post!\n")
}
