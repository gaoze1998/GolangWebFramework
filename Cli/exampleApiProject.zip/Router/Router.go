package Router

import (
	"github.com/gaoze1998/GolangWebFramework/BaseRouter"
)

//RTableInit 初始化路由表
func RTableInit() *BaseRouter.Router {
	router := BaseRouter.Init()

	//在此处编写路由
	router.Register("/gwft", &Controller.MainController{})
	router.Register("/gwft/second", &Controller.SecondController{})
	router.Register("/gwft/testmodel", &Controller.TestModelController{})

	return router
}
