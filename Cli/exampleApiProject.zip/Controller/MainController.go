package Controller

import (
	"github.com/gaoze1998/GolangWebFramework/BaseController"
	"github.com/gaoze1998/GolangWebFramework/BaseSession"
	"fmt"
	"io"
)

type MainController struct {
	BaseController.BaseController
}

func (mc MainController) Get() {
	err := mc.Req.ParseForm()
	if err != nil {
		fmt.Println("表单解析错误")
		return
	}
	bs := BaseSession.BaseSession{}
	bs.Create()
	bs.KV["name"] = mc.Req.Form.Get("name")
	bs.KV["name2"] = mc.Req.Form.Get("name2")
	bs.Save(mc.RespWriter)

	fmt.Println("MainConTroller get!")
	io.WriteString(mc.RespWriter, "hello, get!\n")
}

func (mc MainController) Post() {
	bs := BaseSession.BaseSession{}
	bs.Read(mc.Req)
	name := bs.KV["name"].(string)
	fmt.Println(name)
	fmt.Println(bs.KV["name2"].(string))

	fmt.Println("MainConTroller post!")
	io.WriteString(mc.RespWriter, "hello, post!\n")
}
